import Image from "next/image";
import { notFound } from "next/navigation";
import { getTranslations } from "next-intl/server";

import { getAnimeDetails } from "@/lib/anime/details";
import type { AnimeProvider } from "@/lib/anime/types";

type Props = {
  params: Promise<{
    locale: string;
    provider: string;
    id: string;
    slug: string;
  }>;
};

const VALID_PROVIDERS: AnimeProvider[] = ["anilist", "jikan", "kitsu"];

const STATUS_KEYS = {
  FINISHED: "statusValues.FINISHED",
  RELEASING: "statusValues.RELEASING",
  NOT_YET_RELEASED: "statusValues.NOT_YET_RELEASED",
  CANCELLED: "statusValues.CANCELLED",
  HIATUS: "statusValues.HIATUS",
} as const;

const FORMAT_KEYS = {
  TV: "formats.TV",
  MOVIE: "formats.MOVIE",
  OVA: "formats.OVA",
  ONA: "formats.ONA",
  SPECIAL: "formats.SPECIAL",
  TV_SHORT: "formats.TV_SHORT",
  MUSIC: "formats.MUSIC",
} as const;

const SEASON_KEYS = {
  WINTER: "seasons.WINTER",
  SPRING: "seasons.SPRING",
  SUMMER: "seasons.SUMMER",
  FALL: "seasons.FALL",
} as const;

function isAnimeProvider(provider: string): provider is AnimeProvider {
  return VALID_PROVIDERS.includes(provider as AnimeProvider);
}

function Metric({ label, value }: { label: string; value: string | null }) {
  return (
    <div className="border-b border-zinc-800 pb-4 last:border-0 last:pb-0">
      <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-zinc-600">
        {label}
      </p>

      <p className="mt-1 text-sm text-zinc-300">{value ?? "—"}</p>
    </div>
  );
}

export default async function AnimePage({ params }: Props) {
  const { locale, provider, id } = await params;

  if (!isAnimeProvider(provider)) {
    notFound();
  }

  const t = await getTranslations({
    locale,
    namespace: "anime",
  });

  const anime = await getAnimeDetails(provider, id);

  if (!anime) {
    notFound();
  }

  const title =
    anime.title.english ||
    anime.title.romaji ||
    anime.title.native ||
    "Unknown anime";

  const translatedFormat = anime.format
    ? t(FORMAT_KEYS[anime.format as keyof typeof FORMAT_KEYS] ?? "unknown")
    : t("unknown");

  const translatedStatus = anime.status
    ? t(STATUS_KEYS[anime.status as keyof typeof STATUS_KEYS] ?? "unknown")
    : t("unknown");

  const translatedSeason =
    anime.season && SEASON_KEYS[anime.season as keyof typeof SEASON_KEYS]
      ? t(SEASON_KEYS[anime.season as keyof typeof SEASON_KEYS])
      : null;

  const seasonValue =
    anime.seasonYear !== null
      ? [String(anime.seasonYear), translatedSeason].filter(Boolean).join(" ")
      : t("unknown");

  return (
    <main className="min-h-screen bg-zinc-950 text-white">
      <section className="relative overflow-hidden">
        {anime.bannerImage && (
          <>
            <Image
              src={anime.bannerImage}
              alt=""
              fill
              priority
              sizes="100vw"
              className="object-cover opacity-20"
            />

            <div className="absolute inset-0 bg-gradient-to-b from-zinc-950/40 via-zinc-950/80 to-zinc-950" />
          </>
        )}

        <div className="relative mx-auto max-w-7xl px-6 pb-20 pt-32 sm:px-10 lg:px-16">
          <div className="grid gap-10 md:grid-cols-[240px_1fr]">
            {anime.coverImage && (
              <div className="relative aspect-[2/3] overflow-hidden rounded-2xl bg-zinc-800 shadow-2xl">
                <Image
                  src={anime.coverImage}
                  alt={title}
                  fill
                  priority
                  sizes="240px"
                  className="object-cover"
                />
              </div>
            )}

            <div className="max-w-4xl self-end">
              <p className="font-mono text-xs uppercase tracking-[0.25em] text-zinc-500">
                {t("brand")}
              </p>

              <h1 className="mt-4 font-[family:var(--font-space-grotesk)] text-5xl font-semibold tracking-[-0.05em] sm:text-6xl lg:text-8xl">
                {title}
              </h1>

              {anime.title.native && anime.title.native !== title && (
                <p className="mt-4 text-lg text-zinc-500">
                  {anime.title.native}
                </p>
              )}

              {anime.genres.length > 0 && (
                <div className="mt-8 flex flex-wrap gap-2">
                  {anime.genres.map((genre) => (
                    <span
                      key={genre}
                      className="rounded-full border border-zinc-700 px-3 py-1 text-xs text-zinc-400"
                    >
                      {genre}
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-7xl gap-16 px-6 py-20 sm:px-10 lg:grid-cols-[1fr_320px] lg:px-16">
        <div>
          <p className="font-mono text-xs uppercase tracking-[0.25em] text-zinc-600">
            {t("synopsis")}
          </p>

          <p className="mt-5 max-w-3xl text-lg leading-8 text-zinc-400">
            {anime.description ?? t("noDescription")}
          </p>
        </div>

        <aside className="space-y-5 rounded-3xl border border-zinc-800 bg-zinc-900/50 p-6">
          <Metric label={t("format")} value={translatedFormat} />

          <Metric label={t("status")} value={translatedStatus} />

          <Metric
            label={t("episodes")}
            value={
              anime.episodes !== null ? String(anime.episodes) : t("unknown")
            }
          />

          <Metric label={t("season")} value={seasonValue} />

          <Metric
            label={t("studio")}
            value={
              anime.studios.length > 0 ? anime.studios.join(", ") : t("unknown")
            }
          />
        </aside>
      </section>
    </main>
  );
}
