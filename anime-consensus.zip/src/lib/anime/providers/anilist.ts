import type { AnimeSearchResult } from "../types";

const ANILIST_ENDPOINT = "https://graphql.anilist.co";

const SEARCH_QUERY = `
  query SearchAnime($search: String!) {
    Page(page: 1, perPage: 8) {
      media(
        search: $search
        type: ANIME
      ) {
        id
        idMal

        title {
          romaji
          english
          native
        }

        synonyms

        coverImage {
          medium
          color
        }

        seasonYear
        format
        episodes
        averageScore
      }
    }
  }
`;

const DETAILS_QUERY = `
  query GetAnime($id: Int) {
    Media(
      id: $id
      type: ANIME
    ) {
      id
      idMal

      title {
        romaji
        english
        native
      }

      synonyms

      description(asHtml: false)

      coverImage {
        extraLarge
        large
        medium
        color
      }

      bannerImage

      format
      status

      season
      seasonYear

      episodes
      duration

      genres

      source

      averageScore
      popularity

      studios {
        nodes {
          name
        }
      }
    }
  }
`;

type AniListAnime = {
  id: number;
  idMal: number | null;

  title: {
    romaji: string | null;
    english: string | null;
    native: string | null;
  };

  synonyms?: string[];

  coverImage?: {
    medium: string | null;
    color: string | null;
  } | null;

  seasonYear: number | null;
  format: string | null;
  episodes: number | null;
  averageScore: number | null;
};

type AniListResponse = {
  data?: {
    Page?: {
      media?: AniListAnime[];
    };
  };

  errors?: Array<{
    message: string;
  }>;
};

export async function searchAniList(
  query: string,
): Promise<AnimeSearchResult[]> {
  const response = await fetch(ANILIST_ENDPOINT, {
    method: "POST",

    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },

    body: JSON.stringify({
      query: SEARCH_QUERY,
      variables: {
        search: query,
      },
    }),

    cache: "no-store",
  });

  if (!response.ok) {
    throw new Error(`AniList request failed: ${response.status}`);
  }

  const payload = (await response.json()) as AniListResponse;

  if (payload.errors?.length) {
    throw new Error(
      payload.errors[0]?.message ?? "AniList GraphQL request failed",
    );
  }

  return (
    payload.data?.Page?.media?.map((anime) => ({
      id: anime.id,

      malId: anime.idMal,

      provider: "anilist",

      title: {
        romaji: anime.title.romaji,
        english: anime.title.english,
        native: anime.title.native,
        synonyms: anime.synonyms ?? [],
      },

      coverImage: anime.coverImage?.medium ?? null,

      color: anime.coverImage?.color ?? null,

      seasonYear: anime.seasonYear,
      format: anime.format,
      episodes: anime.episodes,
      score: anime.averageScore !== null ? anime.averageScore / 10 : null,
    })) ?? []
  );
}

export async function getAniListAnime(
  id: number,
): Promise<AnimeDetails | null> {
  const response = await fetch(ANILIST_ENDPOINT, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify({
      query: DETAILS_QUERY,
      variables: {
        id,
      },
    }),
    cache: "no-store",
  });

  if (!response.ok) {
    throw new Error(`AniList detail request failed: ${response.status}`);
  }

  const payload = (await response.json()) as {
    data?: {
      Media?: {
        id: number;
        idMal: number | null;

        title: {
          romaji: string | null;
          english: string | null;
          native: string | null;
        };

        synonyms?: string[];

        description: string | null;

        coverImage?: {
          extraLarge: string | null;
          large: string | null;
          medium: string | null;
          color: string | null;
        } | null;

        bannerImage: string | null;

        format: string | null;
        status: string | null;

        season: string | null;
        seasonYear: number | null;

        episodes: number | null;
        duration: number | null;

        genres?: string[];

        source: string | null;

        averageScore: number | null;
        popularity: number | null;

        studios?: {
          nodes?: Array<{
            name: string;
          }>;
        };
      };
    };

    errors?: Array<{
      message: string;
    }>;
  };

  if (payload.errors?.length) {
    throw new Error(
      payload.errors[0]?.message ?? "AniList detail request failed",
    );
  }

  const anime = payload.data?.Media;

  if (!anime) {
    return null;
  }

  return {
    reference: {
      provider: "anilist",
      id: anime.id,
      malId: anime.idMal,
    },

    title: {
      romaji: anime.title.romaji,
      english: anime.title.english,
      native: anime.title.native,
      synonyms: anime.synonyms ?? [],
    },

    description: anime.description ?? null,

    coverImage:
      anime.coverImage?.extraLarge ??
      anime.coverImage?.large ??
      anime.coverImage?.medium ??
      null,

    bannerImage: anime.bannerImage ?? null,

    color: anime.coverImage?.color ?? null,

    format: anime.format,
    status: anime.status,

    season: anime.season,
    seasonYear: anime.seasonYear,

    episodes: anime.episodes,
    duration: anime.duration,

    genres: anime.genres ?? [],

    studios: anime.studios?.nodes?.map((studio) => studio.name) ?? [],

    source: anime.source,

    score: anime.averageScore !== null ? anime.averageScore / 10 : null,

    popularity: anime.popularity ?? null,
  };
}
