import type { AnimeDetails, AnimeSearchResult } from "../types";

const JIKAN_ENDPOINT = "https://api.jikan.moe/v4/anime";

type JikanAnime = {
  mal_id: number;
  title: string;
  title_english: string | null;
  title_japanese: string | null;
  title_synonyms?: string[];

  images?: {
    jpg?: {
      image_url?: string | null;
    };
  };

  year?: number | null;
  type?: string | null;
  episodes?: number | null;
  score?: number | null;
};

type JikanResponse = {
  data?: JikanAnime[];
};

export async function searchJikan(query: string): Promise<AnimeSearchResult[]> {
  const url = new URL(JIKAN_ENDPOINT);

  url.searchParams.set("q", query);
  url.searchParams.set("limit", "8");
  url.searchParams.set("sfw", "true");

  const response = await fetch(url, {
    headers: {
      Accept: "application/json",
    },
    cache: "no-store",
  });

  if (!response.ok) {
    throw new Error(`Jikan request failed: ${response.status}`);
  }

  const payload = (await response.json()) as JikanResponse;

  return (
    payload.data?.map((anime) => ({
      id: anime.mal_id,
      malId: anime.mal_id,
      provider: "jikan",

      title: {
        romaji: anime.title ?? null,
        english: anime.title_english ?? null,
        native: anime.title_japanese ?? null,
        synonyms: anime.title_synonyms ?? [],
      },

      coverImage: anime.images?.jpg?.image_url ?? null,

      color: null,

      seasonYear: anime.year ?? null,
      format: anime.type ?? null,
      episodes: anime.episodes ?? null,
      score: anime.score ?? null,
    })) ?? []
  );
}
export async function getJikanAnime(id: string): Promise<AnimeDetails | null> {
  const response = await fetch(
    `https://api.jikan.moe/v4/anime/${encodeURIComponent(id)}`,
    {
      headers: {
        Accept: "application/json",
      },
      cache: "no-store",
    },
  );

  if (response.status === 404) {
    return null;
  }

  if (!response.ok) {
    throw new Error(`Jikan detail request failed: ${response.status}`);
  }

  const payload = (await response.json()) as {
    data?: {
      mal_id: number;

      title?: string | null;
      title_english?: string | null;
      title_japanese?: string | null;
      title_synonyms?: string[];

      synopsis?: string | null;

      images?: {
        jpg?: {
          large_image_url?: string | null;
          image_url?: string | null;
        };
      };

      type?: string | null;
      status?: string | null;

      season?: string | null;
      year?: number | null;

      episodes?: number | null;
      duration?: string | null;

      genres?: Array<{
        name: string;
      }>;

      studios?: Array<{
        name: string;
      }>;

      source?: string | null;

      score?: number | null;
      members?: number | null;
    };
  };

  const anime = payload.data;

  if (!anime) {
    return null;
  }

  return {
    reference: {
      provider: "jikan",
      id: anime.mal_id,
      malId: anime.mal_id,
    },

    title: {
      romaji: anime.title ?? null,
      english: anime.title_english ?? null,
      native: anime.title_japanese ?? null,
      synonyms: anime.title_synonyms ?? [],
    },

    description: anime.synopsis ?? null,

    coverImage:
      anime.images?.jpg?.large_image_url ??
      anime.images?.jpg?.image_url ??
      null,

    bannerImage: null,

    color: null,

    format: anime.type ?? null,

    status: anime.status ?? null,

    season: anime.season ?? null,

    seasonYear: anime.year ?? null,

    episodes: anime.episodes ?? null,

    duration: null,

    genres: anime.genres?.map((genre) => genre.name) ?? [],

    studios: anime.studios?.map((studio) => studio.name) ?? [],

    source: anime.source ?? null,

    score: anime.score ?? null,

    popularity: anime.members ?? null,
  };
}
