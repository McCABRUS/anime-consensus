export type AnimeProvider = "jikan" | "anilist" | "kitsu";

export type AnimeReference = {
  provider: AnimeProvider;
  id: string | number;
  malId: number | null;
};

export type AnimeSearchResult = {
  id: number | string;
  malId: number | null;
  provider: AnimeProvider;

  title: {
    romaji: string | null;
    english: string | null;
    native: string | null;
    synonyms: string[];
  };

  coverImage: string | null;
  color: string | null;
  seasonYear: number | null;
  format: string | null;
  episodes: number | null;
  score: number | null;
};

export type AnimeDetails = {
  reference: AnimeReference;

  title: {
    romaji: string | null;
    english: string | null;
    native: string | null;
    synonyms: string[];
  };

  description: string | null;

  coverImage: string | null;
  bannerImage: string | null;

  color: string | null;

  format: string | null;
  status: string | null;

  season: string | null;
  seasonYear: number | null;

  episodes: number | null;
  duration: number | null;

  genres: string[];
  studios: string[];

  source: string | null;

  score: number | null;
  popularity: number | null;
};
